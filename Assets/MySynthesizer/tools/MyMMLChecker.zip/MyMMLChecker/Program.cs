﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.IO;
using System.Linq;

using MySpace;
using MySpace.Synthesizer;

namespace MyMMLChecker
{
    class Program
    {
        static void WriteLine(string str)
        {
#if DEBUG
            Debug.WriteLine(str);
#else
            Console.WriteLine(str);
#endif
        }
        static void Write(string str)
        {
#if DEBUG
            Debug.Write(str);
#else
            Console.Write(str);
#endif
        }
        static private bool Verbose = false;
        static private bool HitAnyKey = true;
        enum ExitCode
        {
            Ok = 0,
            Usage = -1,
            ReadFailed = -2,
            PaserError = -3,
            WriteFailed = -4,
            Exception = -5,
            Canceled = -6,
        }
        static void Exit(ExitCode ec, string message)
        {
            WriteLine(message);
            if (HitAnyKey)
            {
                WriteLine("HIT ANY KEY!");
                Console.ReadKey();
            }
            Environment.Exit((int)ec);
        }
        private class MyTraceListener : TraceListener
        {
            public override void Write(string message)
            {
                Console.Write(message);
            }
            public override void WriteLine(string message)
            {
                Console.WriteLine(message);
            }
        }
        static int Main(string[] args)
        {
            MyDebugOutput.Output += (a) => System.Diagnostics.Debug.WriteLine(a);
            Debug.Listeners.Add(new MyTraceListener());
            bool error = false;
            bool play = false;
            bool loop = false;
            float volume = -1.0f;
            bool output = false;
            string outputfile = null;
            string inputfile = null;
            string resourcePath = null;
            List<string> presetToneFiles = new List<string>();
            uint outputFreq = 0;
            uint bps = 0;
            uint numVoices = 0;
            uint baseFreq = 0;
            uint tickFreq = 0;
            var ct = StringComparison.CurrentCultureIgnoreCase;
            for (int i = 0; i < args.Length; i++)
            {
                var s = args[i];
                if (s[0] != '-')
                {
                    if (inputfile != null)
                    {
                        error = true;
                    }
                    inputfile = s;
                }
                else if (s.Equals("-v", ct) || s.Equals("-verbose", ct))
                {
                    Verbose = true;
                }
                else if (s.Equals("-p", ct) || s.Equals("-play", ct))
                {
                    play = true;
                }
                else if (s.Equals("-l", ct) || s.Equals("-loop", ct))
                {
                    loop = true;
                }
                else if (s.Equals("-h", ct) || s.Equals("-hit", ct))
                {
                    HitAnyKey = true;
                }
                else if (s.Equals("-o", ct) || s.Equals("-output", ct))
                {
                    if (outputfile != null)
                    {
                        error = true;
                    }
                    output = true;
                    if ((i + 1) < args.Length)
                    {
                        if (!args[i + 1].StartsWith("-"))
                        {
                            outputfile = args[++i];
                        }
                    }
                }
                else if (s.Equals("-f", ct) || s.Equals("-frequency", ct))
                {
                    int result;
                    if ((outputFreq == 0) && ((i + 1) < args.Length) && int.TryParse(args[++i], out result))
                    {
                        if ((result < 8000) || (result > 192000))
                        {
                            error = true;
                        }
                        outputFreq = (uint)result;
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-b", ct) || s.Equals("-bps", ct))
                {
                    int result;
                    if ((bps == 0) && ((i + 1) < args.Length) && int.TryParse(args[++i], out result))
                    {
                        switch (result)
                        {
                            case 8:
                            case 16:
                            case 24:
                            case 32:
                                bps = (uint)(result / 8);
                                break;
                            default:
                                error = true;
                                break;
                        }
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-nv", ct) || s.Equals("-maxnumvoices", ct))
                {
                    int result;
                    if ((numVoices == 0) && ((i + 1) < args.Length) && int.TryParse(args[++i], out result))
                    {
                        if ((result < 1) || (result > 32))
                        {
                            error = true;
                        }
                        numVoices = (uint)result;
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-bf", ct) || s.Equals("-basefrequency", ct))
                {
                    int result;
                    if ((baseFreq == 0) && ((i + 1) < args.Length) && int.TryParse(args[++i], out result))
                    {
                        if ((result < 8000) || (result > 192000))
                        {
                            error = true;
                        }
                        baseFreq = (uint)result;
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-tf", ct) || s.Equals("-tickfrequency", ct))
                {
                    int result;
                    if ((tickFreq == 0) && ((i + 1) < args.Length) && int.TryParse(args[++i], out result))
                    {
                        if ((result < 1) || (result > 192000))
                        {
                            error = true;
                        }
                        tickFreq = (uint)result;
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-m", ct) || s.Equals("-mastervolume", ct))
                {
                    float result;
                    if ((volume < 0.0f) && ((i + 1) < args.Length) && float.TryParse(args[++i], out result))
                    {
                        if ((result < 0.0f) || (result > 1.0f))
                        {
                            error = true;
                        }
                        volume = result;
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-r", ct) || s.Equals("-resourcepath", ct))
                {
                    if (resourcePath != null)
                    {
                        error = true;
                    }
                    if ((i + 1) < args.Length)
                    {
                        resourcePath = args[++i];
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-t", ct) || s.Equals("-presettone", ct))
                {
                    if ((i + 1) < args.Length)
                    {
                        presetToneFiles.Add(args[++i]);
                    }
                    else
                    {
                        error = true;
                    }
                }
                else
                {
                    error = true;
                }
            }
            if (play && output)
            {
                error = true;
            }
            if (output && loop)
            {
                error = true;
            }
            if (inputfile == null)
            {
                error = true;
            }
            if (play && ((outputFreq != 0) || (bps != 0)))
            {
                WriteLine("warning; freq & bps is ignored.");
            }
            if (error)
            {
                Exit(ExitCode.Usage, "usage:\n" +
                    "> MyMMLChecker input.mml.txt [-v] [-h] [-t tone.mml.txt] [-r path]\n" +
                    "> MyMMLChecker input.mml.txt [-v] [-h] [-t tone.mml.txt] [-r path] -o [input.wav] [-f 44100] [-b 16] [-m 0.5]\n" +
                    "> MyMMLChecker input.mml.txt [-v] [-h] [-t tone.mml.txt] [-r path] -p [-l] [-m 0.5]\n" +
                    "-v: Verbose\n" +
                    "-h: Hit Any Key!\n" +
                    "-p: Play direct\n" +
                    "-l: Loop\n" +
                    "-m: Master volume (0.0~1.0)\n" +
                    "-o: Output to file\n" +
                    "-f: Frequency(8000~..)\n" +
                    "-b: Bps(8,16,..)\n" +
                    "-nv: Numver of voices (1~32)\n" +
                    "-bf: Base frequency (8000~..)\n" +
                    "-tf: Tick frequency (1~..)\n" +
                    "-r: Resource data path\n" +
                    "-t: tone file\n"
                    );
            }
            volume *= volume;
            if (numVoices == 0)
            {
                numVoices = 8;
            }
            if (baseFreq == 0)
            {
                baseFreq = 31250;
            }
            if (resourcePath == null)
            {
                int i = inputfile.LastIndexOfAny(new char[] { '\\', '/' });
                if (i < 0)
                {
                    resourcePath = "";
                }
                else
                {
                    resourcePath = inputfile.Substring(0, i + 1);
                }
            }
            if (output && (outputfile == null))
            {
                int i = inputfile.LastIndexOf('.');
                if (i < 0)
                {
                    outputfile = inputfile + ".wav";
                }
                else
                {
                    outputfile = inputfile.Substring(0, i) + ".wav";
                }
            }

            string txt;
#if !DEBUG
            try
#endif
            {
                using (var sr = new System.IO.StreamReader(inputfile, Encoding.UTF8, true))
                {
                    txt = sr.ReadToEnd();
                }
            }
#if !DEBUG
            catch (Exception e)
            {
                Exit(ExitCode.ReadFailed, e.Message);
                return 0;
            }
#endif

            MyMMLSequence sequence = MyMMLSequence.Parse(txt);
            if (sequence.ErrorLine != 0)
            {
                Exit(ExitCode.PaserError, "ParseFailed " + sequence.ErrorLine + ":" + sequence.ErrorPosition + ":" + sequence.ErrorString + " <<< " + sequence.ErrorMessage);
            }

#if !DEBUG
            try
#endif
            {
                MMLPlayer player = new MMLPlayer(resourcePath, numVoices, outputFreq, baseFreq, tickFreq, output, Verbose);
                player.SetupPresetTones(presetToneFiles);
                if (play)
                {
                    player.PlayMML(sequence, volume, loop);
                }
                else if (output)
                {
                    if (outputFreq == 0)
                    {
                        outputFreq = 44100;
                    }
                    if (bps == 0)
                    {
                        bps = 2;
                    }
                    player.RenderToFile(outputfile, bps, sequence, volume);
                }
            }
#if !DEBUG
            catch (System.Exception e)
            {
                Exit(ExitCode.Exception, e.Message);
                return 0;
            }
#endif
            Exit(ExitCode.Ok, "Ok..");
            return 0;
        }
        private class MMLPlayer
        {
            private const uint bufferSize = 200;  // msec

            private string resourcePath;
            private readonly MyMixer mix;
            private readonly MyMMLSequencer seq;
            private readonly MySynthesizer[] sss;
            private readonly MyThread seqThread;
            private readonly Dictionary<string, MySoundFont2.SF2Bank> sf2BankMap;
            private int tickCount;
            private bool verbose;

            private MySoundFont2.SF2Bank LoadSF2Bank(string resourceName)
            {
                MySoundFont2.SF2Bank sf2;
                if (!sf2BankMap.TryGetValue(resourceName, out sf2))
                {
#if !DEBUG
                    try
#endif
                    {
                        using (var fs = new System.IO.FileStream(resourcePath + resourceName, FileMode.Open, System.IO.FileAccess.Read))
                        {
                            var sf2image = new byte[fs.Length];
                            fs.Read(sf2image, 0, sf2image.Length);
                            sf2 = MySoundFont2.Parse(sf2image);
                        }
                    }
#if !DEBUG
                    catch (Exception e)
                    {
                        Exit(ExitCode.ReadFailed, e.Message);
                        return null;
                    }
#endif
                }
                return sf2;
            }
            private void SetupToneMap(ToneMap toneMap, List<MyMMLSequence.ToneInfo> toneInfos)
            {
                if (toneInfos == null)
                {
                    return;
                }
                foreach (var toneInfo in toneInfos)
                {
                    var ts = MySynthesizer.CreateToneSet(toneInfo.Data);
                    if (ts == null)
                    {
                        continue;
                    }
                    ts.Name = toneInfo.Name;
                    foreach (var t in ts)
                    {
                        if (t is MySynthesizerSS8.ToneParam)
                        {
                            var tone = t as MySynthesizerSS8.ToneParam;
                            {
                                string filename = tone.ResourceName + ".wav";
                                int ll = filename.LastIndexOfAny(new char[] { '\\', '/' });
                                if (ll >= 0)
                                {
                                    filename = filename.Substring(ll);
                                }
                                float[] samples = LoadMonaural(resourcePath + filename);
                                tone.SetSamples(samples);
                            }
                        }
                        if (t is MySynthesizerSF2.ToneParam)
                        {
                            var tone = t as MySynthesizerSF2.ToneParam;
                            var sf2 = LoadSF2Bank(tone.ResourceName);
                            if (sf2 != null)
                            {
                                tone.SetBank(sf2);
                            }
                        }
                    }
                    ToneSet toneSet;
                    toneMap.TryGetValue(toneInfo.PresetNo, out toneSet);
                    if (toneSet == null)
                    {
                        toneSet = ts;
                    }
                    else
                    {
                        ts.AddRange(toneSet);
                        toneSet = ts;
                    }
                    if (toneSet.Count != 0)
                    {
                        toneMap[toneInfo.PresetNo] = toneSet;
                    }
                }
            }
            private void SetupSF2ToneMap(ToneMap toneMap, MyMMLSequence seq, string resourcePath)
            {
                string sf2prop;
                if (seq.Property.TryGetValue("SoundFont2", out sf2prop))
                {
                    var ss = sf2prop.Split('\n');
                    foreach (var resourceName in ss)
                    {
                        var sf2 = LoadSF2Bank(resourceName);
                        if (sf2 != null)
                        {
                            var tm = MySynthesizerSF2.CreateToneMap(sf2);
                            toneMap.Merge(tm);
                        }
                    }
                }
            }
            private void SetupToneMap(ToneMap toneMap, MyMMLSequence seq)
            {
                SetupToneMap(toneMap, seq.ToneInfos);
                SetupSF2ToneMap(toneMap, seq, resourcePath);
            }
            public void SetupPresetTones(List<string> presetToneFiles)
            {
                var toneMap = new ToneMap();
                foreach (var tonefile in presetToneFiles)
                {
                    string mml;
#if !DEBUG
                    try
#endif
                    {
                        using (var sr = new System.IO.StreamReader(tonefile, Encoding.UTF8, true))
                        {
                            mml = sr.ReadToEnd();
                        }
                    }
#if !DEBUG
                    catch (Exception e)
                    {
                        Exit(ExitCode.ReadFailed, e.Message);
                        return;
                    }
#endif

                    var sequence = MyMMLSequence.Parse(mml);
                    if (sequence.ErrorLine != 0)
                    {
                        Exit(ExitCode.PaserError, " ParseFailed " + tonefile + ":" + sequence.ErrorLine + ":" + sequence.ErrorPosition + ":" + sequence.ErrorString + " <<<");
                    }
                    SetupToneMap(toneMap, sequence);
                }
                if (toneMap.Count != 0)
                {
                    foreach (var syn in sss)
                    {
                        syn.AddToneMap(toneMap);
                    }
                }
            }
            public MMLPlayer(string resourcePath, uint numVoices, uint outputFreq, uint baseFreq, uint tickFreq, bool offline, bool verbose)
            {
                this.verbose = verbose;
                this.resourcePath = resourcePath;
                if (outputFreq == 0)
                {
                    outputFreq = MySpace.DirectSound.MyDirectStream.Frequency;
                }
                if (tickFreq == 0)
                {
                    tickFreq = baseFreq / 256;
                }
                sf2BankMap = new Dictionary<string, MySoundFont2.SF2Bank>();
                mix = new MyMixer(outputFreq, offline, bufferSize, baseFreq, tickFreq);
                seq = new MyMMLSequencer(mix.TickFrequency);
                sss = new MySynthesizer[MyMMLSequence.MaxNumPorts];
                sss[0] = new MySynthesizerPM8(mix, numVoices);
                sss[1] = new MySynthesizerSS8(mix, numVoices);
                sss[2] = new MySynthesizerCT8(mix, numVoices);
                sss[3] = new MySynthesizerSF2(mix, numVoices);
                for (int i = 0; i < sss.Length; i++)
                {
                    if (sss[i] == null)
                    {
                        continue;
                    }
                    seq.SetSynthesizer(i, sss[i], 0xffffffffU);
                }
                if (verbose)
                {
                    seq.AppDataEvent += (loc, data) =>
                    {
                        WriteLine(data);
                    };
                    seq.PlayingEvent += (loc, step, gate, ist) =>
                    {
#if !DEBUG
                        if (ist.N == MyMMLSequence.InstructionNote.Rest)
                        {
                            return;
                        }
#endif
                        uint tb = 32;// 96;
                        var timeBase = seq.TimeBase;
                        var tc = loc.StepTime * tb / timeBase;
                        var st = step * tb / timeBase;
                        var gt = gate * tb / timeBase;
                        string str = "" +
                            loc.TrackNo.ToString("D2") + ":" + loc.Channel.ToString("D2") + " " +
                            loc.MeasureCount.ToString("D3") + ":" +
                            tc.ToString("D3") + " " +
                            st.ToString("D3") + ":" +
                            gt.ToString("D3") + " ";
                        if ((int)ist.N == 0)
                        {
                            str += "" + ist.N;
                        }
                        else if ((int)ist.N < 128)
                        {
#if DEBUG
                            str += ((int)ist.N).ToString("D3") + " " + ist.V.ToString("D3");
#else
                            char c0 = "ccddeffggaab"[(int)ist.N % 12];
                            char c1 = " # #  # # # "[(int)ist.N % 12];
                            int oct = ((int)ist.N / 12) - 2;
                            str += "" + c0 + c1 + oct + " " + ist.V.ToString("D3");
#endif
                        }
                        else if (ist.N == MyMMLSequence.InstructionNote.ProgramChange)
                        {
                            str += "" + ist.N + " <" + ist.L.ToString() + "," + ist.D.ToString() + "," + ist.V.ToString() + ">";
                        }
                        else
                        {
                            str += "" + ist.N + " <0x" + ((ist.Q << 7) | ist.V).ToString("X4") + ">";
                        }
                        WriteLine(str);
                    };
                    seq.NextSectionEvent += (loc, nextSection) =>
                    {
                        if (nextSection < 0)
                        {
                            WriteLine("End");
                        }
                        else
                        {
                            WriteLine("Section No." + nextSection);
                            foreach (var tag in loc.Sequence.Score[nextSection].Tags)
                            {
                                WriteLine("#" + tag);
                            }
                        }
                        return nextSection;
                    };
                }
                if (outputFreq == 0)
                {
                    tickCount = 0;
                    seqThread = new MyThread();
                    seqThread.Start(() =>
                    {
                        var count = System.Threading.Interlocked.Exchange(ref tickCount, 0);
                        while (count-- != 0)
                        {
                            seq.Tick();
                        }
                    });
                    mix.TickCallback += () =>
                    {
                        System.Threading.Interlocked.Increment(ref tickCount);
                        seqThread.Raise();
                    };
                }
                else
                {
                    mix.TickCallback += seq.Tick;
                }
            }
            private bool Setup(MyMMLSequence sequence, out ToneMap toneMap)
            {
                sf2BankMap.Clear();
                toneMap = new ToneMap();
                SetupToneMap(toneMap, sequence);

                if (verbose)
                {
                    foreach (var pair in sequence.Property)
                    {
                        WriteLine("<" + pair.Key + "> = " + pair.Value);
                    }
                }
                return true;
            }
            private int GetDefaultVariation(MyMMLSequence sequence)
            {
                string variationProp;
                if (!sequence.Property.TryGetValue("Variation", out variationProp))
                {
                    return 0;
                }
                int variation;
                if (!int.TryParse(variationProp, out variation))
                {
                    return 0;
                }
                return variation;
            }
            public void PlayMML(MyMMLSequence sequence, float volume, bool loop)
            {
                ToneMap toneMap;
                if (!Setup(sequence, out toneMap))
                {
                    return;
                }

                var canceled = false;
                mix.MasterVolume = volume;
                seq.KeyShift = 0;
                seq.VolumeScale = 1.0f;
                seq.TempoScale = 1.0f;
                seq.Play(sequence, toneMap, 0.0f, loop, 0, GetDefaultVariation(sequence), false);

                var mth = new MyThread();
                using (var mds = new MySpace.DirectSound.MyDirectStream())
                {
                    mds.Play((data, numSamples) =>
                    {
                        mix.Output(data, 2, numSamples);
                    });
                    mth.Start(mix.Update);
                    while (seq.Playing)
                    {
                        System.Threading.Thread.Sleep(10);
                        mth.Raise();
                        mds.Raise();
                        if (!canceled && Console.KeyAvailable)
                        {
                            var key = Console.ReadKey(true);
                            if (key.Key == ConsoleKey.Escape)
                            {
                                seq.Stop(1.0f);
                                canceled = true;
                                HitAnyKey = false;
                            }
                        }
                    }
                    for (int i = 0; i < bufferSize / 16; i++)
                    {
                        System.Threading.Thread.Sleep(10);
                        mth.Raise();
                        mds.Raise();
                    }
                    mds.Stop();
                    mth.Stop();
                }
                foreach (MySynthesizer s in sss)
                {
                    if (s != null)
                    {
                        s.Terminate();
                    }
                }
                mix.Terminate();
            }
            public void RenderToFile(string outputfile, uint bps, MyMMLSequence sequence, float volume)
            {
                ToneMap toneMap;
                if (!Setup(sequence, out toneMap))
                {
                    return;
                }

                mix.MasterVolume = volume;
                seq.KeyShift = 0;
                seq.VolumeScale = 1.0f;
                seq.TempoScale = 1.0f;
                seq.Play(sequence, toneMap, 0.0f, false);

                System.Diagnostics.Stopwatch sw = new System.Diagnostics.Stopwatch();
                sw.Start();
                using (var ww = new WaveWriter(outputfile, mix.OutputSampleRate, bps))
                {
                    int sectorSize = 588;
                    int count = 0;
                    int seconds = 0;
                    float[] sector = new float[sectorSize * 2];
                    bool zeroCross = false;
                    for (; ; )
                    {
                        if (seq.Playing)
                        {
                            mix.Update();
                            if (Console.KeyAvailable)
                            {
                                var key = Console.ReadKey(true);
                                if (key.Key == ConsoleKey.Escape)
                                {
                                    HitAnyKey = false;
                                    break;
                                }
                            }
                        }
                        Array.Clear(sector, 0, sector.Length);
                        int num = mix.Output(sector, 2, sectorSize);
                        if (num == 0)
                        {
                            if (!zeroCross)
                            {
                                mix.Update();
                                continue;
                            }
                            break;
                        }
                        float v0 = sector[(num - 1) * 2 + 0];
                        float v1 = sector[(num - 1) * 2 + 1];
                        zeroCross = (v0 == 0.0f) && (v1 == 0.0f);
                        ww.Write(sector, num);
                        count += num;
                        if (count > sectorSize * 75)
                        {
                            count %= sectorSize * 75;
                            seconds++;
                            if (!verbose)
                            {
                                Write(".");
                            }
                        }
                    }
                    if (count != 0)
                    {
                        seconds++;
                    }
                    if (!verbose)
                    {
                        Write("\n");
                    }
                    WriteLine("total output time is " + seconds + " seconds");
                    ww.Close();
                    mix.Terminate();
                    foreach (var s in sss)
                    {
                        if (s != null)
                        {
                            s.Terminate();
                        }
                    }
                }
                sw.Stop();
                //WriteLine("caluculation time is " + (int)Math.Ceiling(sw.Elapsed.TotalSeconds) + " seconds");
                WriteLine("caluculation time is " + sw.Elapsed.TotalSeconds + " seconds");
            }
            static float[] LoadMonaural(string filePath)
            {
                var wr = new WaveReader(filePath);
                float[] samples = new float[wr.Samples];
                wr.Read(samples);
                if (wr.Channels != 1)
                {
                    float[] mixed = new float[wr.Samples / wr.Channels];
                    int idx = 0;
                    for (int i = 0; i < mixed.Length; i++)
                    {
                        float s = 0.0f;
                        for (int j = 0; j < wr.Channels; j++)
                        {
                            float v = samples[idx++];
                            s += v;
                        }
                        mixed[i] = s;
                    }
                    samples = mixed;
                }
                return samples;
            }
        }
    }
    class WaveWriter : IDisposable
    {
        private bool disposed = false;
        private FileStream fileStream;
        private BinaryWriter binaryWriter;
        private long dataPos;
        private uint bps;
        /// <summary>8bit,16bit,24bit and 32bit float</summary>
        /// <param name="path"></param>
        /// <param name="freq"></param>
        /// <param name="bytesPerSample"></param>
        public WaveWriter(string path, uint freq, uint bytesPerSample)
        {
            bps = (bytesPerSample > 4) ? 2 : ((bytesPerSample == 0) ? 2 : bytesPerSample);
            fileStream = new FileStream(path, FileMode.Create, FileAccess.Write);
            binaryWriter = new BinaryWriter(fileStream);

            binaryWriter.Write(new byte[4] { (byte)'R', (byte)'I', (byte)'F', (byte)'F' });
            binaryWriter.Write((UInt32)(4 + 4 + 4 + 2 + 2 + 4 + 4 + 2 + 2 + 4 + 4 + 0 * 2 * 2));   // size

            binaryWriter.Write(new byte[4] { (byte)'W', (byte)'A', (byte)'V', (byte)'E' });
            binaryWriter.Write(new byte[4] { (byte)'f', (byte)'m', (byte)'t', (byte)' ' });
            binaryWriter.Write((UInt32)(16));
            if (bps < 4)
            {
                binaryWriter.Write((UInt16)(1));            // format 1:linear pcm
            }
            else
            {
                binaryWriter.Write((UInt16)(3));            // format 3:32bit float
            }
            binaryWriter.Write((UInt16)(2));                // channels

            binaryWriter.Write((UInt32)(freq));             // samples per sec
            binaryWriter.Write((UInt32)(freq * bps * 2));   // bytes per sec
            binaryWriter.Write((UInt16)(bps * 2));          // bytes per sample * channels
            binaryWriter.Write((UInt16)(bps * 8));          // bits per sample

            binaryWriter.Write(new byte[4] { (byte)'d', (byte)'a', (byte)'t', (byte)'a' });
            binaryWriter.Write((UInt32)(0));
            dataPos = binaryWriter.Seek(0, SeekOrigin.Current);
        }
        ~WaveWriter()
        {
            Dispose(false);
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    this.Close();
                }
                this.disposed = true;
            }
        }
        public void Close()
        {
            if (fileStream != null)
            {
                long len = binaryWriter.Seek(0, SeekOrigin.Current);
                binaryWriter.Seek(4, SeekOrigin.Begin);
                binaryWriter.Write((UInt32)(len - 8));
                binaryWriter.Seek((int)(dataPos - 4), SeekOrigin.Begin);
                binaryWriter.Write((UInt32)(len - dataPos));
                binaryWriter.Close();
                binaryWriter = null;
                fileStream.Close();
                fileStream = null;
            }
        }
        public void Write(float[] stereoSamples, int numSamples)
        {
            for (int i = 0; i < numSamples * 2; i++)
            {
                float v = stereoSamples[i];
                v = (v < -1.0f) ? -1.0f : (v > +1.0f ? +1.0f : v);
                switch (bps)
                {
                    case 1:
                        {
                            Byte d = (Byte)(v * ((1 << 7) - 1) + 128.0f);
                            binaryWriter.Write(d);
                        }
                        break;
                    default:
                    case 2:
                        {
                            Int16 d = (Int16)(v * ((1 << 15) - 1));
                            binaryWriter.Write(d);
                        }
                        break;
                    case 3:
                        {
                            Int32 d = (Int32)(v * ((1 << 23) - 1));
                            binaryWriter.Write((Byte)((d >> 0) & 0xffU));
                            binaryWriter.Write((Byte)((d >> 8) & 0xffU));
                            binaryWriter.Write((Byte)((d >> 16) & 0xffU));
                        }
                        break;
                    case 4:
                        binaryWriter.Write(v);
                        break;
                }
            }
        }
    }
    class WaveReader : IDisposable
    {
        private bool disposed = false;
        private FileStream fileStream;
        private BinaryReader binaryReader;
        private int dataPos;
        private int dataNum;
        public int Channels { get; private set; }
        public int Frequency { get; private set; }
        public int Samples { get; private set; }
        private int bps;
        private void CheckTag(byte[] id)
        {
            byte[] read = binaryReader.ReadBytes(id.Length);
            for (int i = 0; i < id.Length; i++)
            {
                if (read[i] != id[i])
                {
                    throw new System.Exception("tag error : <" + read + "> != <" + id + ">");
                }
            }
        }
        /// <param name="path"></param>
        public WaveReader(string path)
        {
            fileStream = new FileStream(path, FileMode.Open, FileAccess.Read);
            binaryReader = new BinaryReader(fileStream);

            CheckTag(new byte[4] { (byte)'R', (byte)'I', (byte)'F', (byte)'F' });
            UInt32 size = binaryReader.ReadUInt32();

            CheckTag(new byte[4] { (byte)'W', (byte)'A', (byte)'V', (byte)'E' });

            CheckTag(new byte[4] { (byte)'f', (byte)'m', (byte)'t', (byte)' ' });
            UInt32 fmtSize = binaryReader.ReadUInt32();     // (UInt32)(16));
            UInt16 format = binaryReader.ReadUInt16();      // 1:linear pcm, 3:32bit float
            UInt16 channels = binaryReader.ReadUInt16();
            UInt32 sampleRate = binaryReader.ReadUInt32();
            UInt32 bytesPerSec = binaryReader.ReadUInt32();
            UInt16 blockSize = binaryReader.ReadUInt16();
            UInt16 bitsPerSample = binaryReader.ReadUInt16();
            if (fmtSize > 16)
            {
                binaryReader.ReadBytes((int)fmtSize - 16);
            }
            Frequency = (int)sampleRate;
            Channels = (int)channels;
            bps = blockSize / channels;
            switch (format)
            {
                case 1:
                    if ((bitsPerSample != 8) && (bitsPerSample != 16) && (bitsPerSample != 24))
                    {
                        throw new System.Exception("Unknown format id=" + format + " bps=" + bitsPerSample);
                    }
                    break;
                case 3:
                    if (bitsPerSample != 32)
                    {
                        throw new System.Exception("Unknown format id=" + format + " bps=" + bitsPerSample);
                    }
                    break;
                default:
                    throw new System.Exception("Format id=" + format + " : not supported");
            }

            for (; ; )
            {
                byte[] chunkTag = binaryReader.ReadBytes(4);
                if (chunkTag.SequenceEqual(new byte[4] { (byte)'d', (byte)'a', (byte)'t', (byte)'a' }))
                {
                    break;
                }
                UInt32 chunkSize = binaryReader.ReadUInt32();
                binaryReader.ReadBytes((int)chunkSize);
            }
            UInt32 dataSize = binaryReader.ReadUInt32();
            dataPos = 0;
            dataNum = (int)dataSize / (bitsPerSample / 8);
            Samples = dataNum;
        }
        ~WaveReader()
        {
            Dispose(false);
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    this.binaryReader.Close();
                    this.binaryReader = null;
                    this.fileStream.Close();
                    this.fileStream = null;
                }
                this.disposed = true;
            }
        }
        public void Close()
        {
            Dispose();
        }
        public int Read(float[] samples)
        {
            int num = 0;
            for (int i = 0; i < samples.Length; i++)
            {
                if (dataPos >= dataNum)
                {
                    samples[i] = 0.0f;
                }
                else
                {
                    num++;
                    switch (bps)
                    {
                        case 1:
                            samples[i] = (binaryReader.ReadByte() - 128.0f) * (1.0f / SByte.MaxValue);
                            break;
                        case 2:
                            samples[i] = (binaryReader.ReadInt16()) * (1.0f / Int16.MaxValue);
                            break;
                        case 3:
                            {
                                byte[] val = binaryReader.ReadBytes(3);
                                Int32 v = ((Int32)val[0] << 8) | ((Int32)val[1] << 16) | ((Int32)val[2] << 24);
                                samples[i] = v * (1.0f / Int32.MaxValue);
                            }
                            break;
                        case 4:
                            samples[i] = binaryReader.ReadSingle();
                            break;
                    }
                    dataPos++;
                }
            }
            return num / Channels;
        }
    }
}
