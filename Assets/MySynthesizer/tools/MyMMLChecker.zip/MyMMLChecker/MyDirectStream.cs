﻿
using System;
using System.Runtime.InteropServices;


namespace MySpace
{
    namespace DirectSound
    {
        // ## Not Supported ##
        // These DirectSound definitions are defective.
        using BYTE = Byte;
        using WORD = UInt16;
        using DWORD = UInt32;
        using LONG = Int32;
        using ULONG = UInt32;
        using D3DVALUE = Single;
        using HANDLE = IntPtr;
        using HWND = IntPtr;
        //using HRESULT = LONG;
        public enum DSRESULT : LONG
        {
            DS_OK = 0x00000000,
            E_INVALIDARG = unchecked((LONG)0x80070057),
            E_FAIL = unchecked((LONG)0x80004005),
            E_OUTOFMEMORY = unchecked((LONG)0x8007000E),
            E_NOTIMPL = unchecked((LONG)0x80004001),
            CLASS_E_NOAGGREGATION = unchecked((LONG)0x80040110),
            E_NOINTERFACE = unchecked((LONG)0x80004002),

            FACDS = unchecked((LONG)0x88780000),
            // The call failed because resources (such as a priority level)
            // were already being used by another caller.
            DSERR_ALLOCATED = FACDS + (10),

            // The control (vol,pan,etc.) requested by the caller is not available.
            DSERR_CONTROLUNAVAIL = FACDS + (30),

            // An invalid parameter was passed to the returning function
            DSERR_INVALIDPARAM = E_INVALIDARG,

            // This call is not valid for the current state of this object
            DSERR_INVALIDCALL = FACDS + (50),

            // An undetermined error occured inside the DirectSound subsystem
            DSERR_GENERIC = E_FAIL,

            // The caller does not have the priority level required for the function to
            // succeed.
            DSERR_PRIOLEVELNEEDED = FACDS + (70),

            // Not enough free memory is available to complete the operation
            DSERR_OUTOFMEMORY = E_OUTOFMEMORY,

            // The specified WAVE format is not supported
            DSERR_BADFORMAT = FACDS + (100),

            // The function called is not supported at this time
            DSERR_UNSUPPORTED = E_NOTIMPL,

            // No sound driver is available for use
            DSERR_NODRIVER = FACDS + (120),

            // This object is already initialized
            DSERR_ALREADYINITIALIZED = FACDS + (130),

            // This object does not support aggregation
            DSERR_NOAGGREGATION = CLASS_E_NOAGGREGATION,

            // The buffer memory has been lost, and must be restored.
            DSERR_BUFFERLOST = FACDS + (150),

            // Another app has a higher priority level, preventing this call from
            // succeeding.
            DSERR_OTHERAPPHASPRIO = FACDS + (160),

            // This object has not been initialized
            DSERR_UNINITIALIZED = FACDS + (170),

            // The requested COM interface is not available
            DSERR_NOINTERFACE = E_NOINTERFACE,
        }

        [Flags]
        public enum DSCAPS_FLAGS : DWORD
        {
            DSCAPS_PRIMARYMONO = 0x00000001,
            DSCAPS_PRIMARYSTEREO = 0x00000002,
            DSCAPS_PRIMARY8BIT = 0x00000004,
            DSCAPS_PRIMARY16BIT = 0x00000008,
            DSCAPS_CONTINUOUSRATE = 0x00000010,
            DSCAPS_EMULDRIVER = 0x00000020,
            DSCAPS_CERTIFIED = 0x00000040,
            DSCAPS_SECONDARYMONO = 0x00000100,
            DSCAPS_SECONDARYSTEREO = 0x00000200,
            DSCAPS_SECONDARY8BIT = 0x00000400,
            DSCAPS_SECONDARY16BIT = 0x00000800,
        }
        public enum DSBPLAY_FLAGS : DWORD
        {
            DSBPLAY_LOOPING = 0x00000001,
        }

        [Flags]
        public enum DSBSTATUS : DWORD
        {
            DSBSTATUS_PLAYING = 0x00000001,
            DSBSTATUS_BUFFERLOST = 0x00000002,
            DSBSTATUS_LOOPING = 0x00000004,
        }

        public enum DSBLOCK_FLAGS : DWORD
        {
            DSBLOCK_FROMWRITECURSOR = 0x00000001,
            DSBLOCK_ENTIREBUFFER = 0x00000002,
        }

        public enum DSSCL : DWORD
        {
            DSSCL_NORMAL = 0x00000001,
            DSSCL_PRIORITY = 0x00000002,
            DSSCL_EXCLUSIVE = 0x00000003,
            DSSCL_WRITEPRIMARY = 0x00000004,
        }

        public enum DS3DMODE : DWORD
        {
            DS3DMODE_NORMAL = 0x00000000,
            DS3DMODE_HEADRELATIVE = 0x00000001,
            DS3DMODE_DISABLE = 0x00000002,
        }
        public enum DS3D : DWORD
        {
            DS3D_IMMEDIATE = 0x00000000,
            DS3D_DEFERRED = 0x00000001,
        }

        [Flags]
        public enum DSBCAPS_FLAGS : DWORD
        {
            DSBCAPS_PRIMARYBUFFER = 0x00000001,
            DSBCAPS_STATIC = 0x00000002,
            DSBCAPS_LOCHARDWARE = 0x00000004,
            DSBCAPS_LOCSOFTWARE = 0x00000008,
            DSBCAPS_CTRL3D = 0x00000010,
            DSBCAPS_CTRLFREQUENCY = 0x00000020,
            DSBCAPS_CTRLPAN = 0x00000040,
            DSBCAPS_CTRLVOLUME = 0x00000080,
            DSBCAPS_CTRLPOSITIONNOTIFY = 0x00000100,
            DSBCAPS_CTRLDEFAULT = 0x000000E0,
            DSBCAPS_CTRLALL = 0x000001F0,
            DSBCAPS_STICKYFOCUS = 0x00004000,
            DSBCAPS_GLOBALFOCUS = 0x00008000,
            DSBCAPS_GETCURRENTPOSITION2 = 0x00010000,
            DSBCAPS_MUTE3DATMAXDISTANCE = 0x00020000,

            DSCBCAPS_WAVEMAPPED = 0x80000000,
        }

        public enum DSSPEAKER_CONFIG : BYTE
        {
            DSSPEAKER_HEADPHONE = 0x00000001,
            DSSPEAKER_MONO = 0x00000002,
            DSSPEAKER_QUAD = 0x00000003,
            DSSPEAKER_STEREO = 0x00000004,
            DSSPEAKER_SURROUND = 0x00000005,
        }
        public static class DSSPEAKER
        {
            public const DWORD DSSPEAKER_GEOMETRY_MIN = 0x00000005;  //   5 degrees
            public const DWORD DSSPEAKER_GEOMETRY_NARROW = 0x0000000A;  //  10 degrees
            public const DWORD DSSPEAKER_GEOMETRY_WIDE = 0x00000014;  //  20 degrees
            public const DWORD DSSPEAKER_GEOMETRY_MAX = 0x000000B4;  // 180 degrees

            public static DWORD DSSPEAKER_COMBINED(BYTE c, BYTE g)
            {
                return ((DWORD)(((BYTE)(c)) | ((DWORD)((BYTE)(g))) << 16));
            }
            public static BYTE DSSPEAKER_CONFIG(DWORD a)
            {
                return ((BYTE)(a));
            }
            public static BYTE DSSPEAKER_GEOMETRY(DWORD a)
            {
                return ((BYTE)(((DWORD)(a) >> 16) & 0x00FF));
            }
        }
        public enum DSCCAPS_FLAGS : DWORD
        {
            DSCCAPS_EMULDRIVER = 0x00000020,
        }

        public enum DSCBLOCK : DWORD
        {
            DSCBLOCK_ENTIREBUFFER = 0x00000001,
        }

        public enum DSCBSTATUS : DWORD
        {
            DSCBSTATUS_CAPTURING = 0x00000001,
            DSCBSTATUS_LOOPING = 0x00000002,
        }

        public enum DSCBSTART : DWORD
        {
            DSCBSTART_LOOPING = 0x00000001,
        }
        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        public struct D3DVECTOR
        {
            float x;
            float y;
            float z;
        }
        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        public class DSCAPS
        {
            public DWORD dwSize = (DWORD)Marshal.SizeOf(typeof(DSCAPS));
            public DSCAPS_FLAGS dwFlags;
            public DWORD dwMinSecondarySampleRate;
            public DWORD dwMaxSecondarySampleRate;
            public DWORD dwPrimaryBuffers;
            public DWORD dwMaxHwMixingAllBuffers;
            public DWORD dwMaxHwMixingStaticBuffers;
            public DWORD dwMaxHwMixingStreamingBuffers;
            public DWORD dwFreeHwMixingAllBuffers;
            public DWORD dwFreeHwMixingStaticBuffers;
            public DWORD dwFreeHwMixingStreamingBuffers;
            public DWORD dwMaxHw3DAllBuffers;
            public DWORD dwMaxHw3DStaticBuffers;
            public DWORD dwMaxHw3DStreamingBuffers;
            public DWORD dwFreeHw3DAllBuffers;
            public DWORD dwFreeHw3DStaticBuffers;
            public DWORD dwFreeHw3DStreamingBuffers;
            public DWORD dwTotalHwMemBytes;
            public DWORD dwFreeHwMemBytes;
            public DWORD dwMaxContigFreeHwMemBytes;
            public DWORD dwUnlockTransferRateHwBuffers;
            public DWORD dwPlayCpuOverheadSwBuffers;
            public DWORD dwReserved1;
            public DWORD dwReserved2;
        }
        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        public class DSBCAPS
        {
            public DWORD dwSize = (DWORD)Marshal.SizeOf(typeof(DSBCAPS));
            public DSBCAPS_FLAGS dwFlags;
            public DWORD dwBufferBytes;
            public DWORD dwUnlockTransferRate;
            public DWORD dwPlayCpuOverhead;
        }
        public enum WAVE_FORMAT : WORD
        {
            WAVE_FORMAT_PCM = 1,
        }
        [StructLayout(LayoutKind.Sequential, Pack = 2)]
        public class WAVEFORMATEX
        {
            public WAVE_FORMAT wFormatTag;
            public WORD nChannels;
            public DWORD nSamplesPerSec;
            public DWORD nAvgBytesPerSec;
            public WORD nBlockAlign;
            public WORD wBitsPerSample;
            public WORD cbSize;
        }
        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        public class DSBUFFERDESC
        {
            public DWORD dwSize = (DWORD)Marshal.SizeOf(typeof(DSBUFFERDESC));
            public DSBCAPS_FLAGS dwFlags;
            public DWORD dwBufferBytes;
            public DWORD dwReserved = 0;
            public IntPtr lpwfxFormat;
        }
        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        public class DS3DBUFFER
        {
            public DWORD dwSize = (DWORD)Marshal.SizeOf(typeof(DS3DBUFFER));
            public D3DVECTOR vPosition;
            public D3DVECTOR vVelocity;
            public DWORD dwInsideConeAngle;
            public DWORD dwOutsideConeAngle;
            public D3DVECTOR vConeOrientation;
            public LONG lConeOutsideVolume;
            public D3DVALUE flMinDistance;
            public D3DVALUE flMaxDistance;
            public DWORD dwMode;
        }
        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        public class DS3DLISTENER
        {
            public DWORD dwSize = (DWORD)Marshal.SizeOf(typeof(DS3DLISTENER));
            public D3DVECTOR vPosition;
            public D3DVECTOR vVelocity;
            public D3DVECTOR vOrientFront;
            public D3DVECTOR vOrientTop;
            public D3DVALUE flDistanceFactor;
            public D3DVALUE flRolloffFactor;
            public D3DVALUE flDopplerFactor;
        }
        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        public class DSCCAPS
        {
            public DWORD dwSize = (DWORD)Marshal.SizeOf(typeof(DSCCAPS));
            public DSCCAPS_FLAGS dwFlags;
            public DWORD dwFormats;
            public DWORD dwChannels;
        }
        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        public class DSCBUFFERDESC
        {
            public DWORD dwSize = (DWORD)Marshal.SizeOf(typeof(DSCBUFFERDESC));
            public DWORD dwFlags;
            public DWORD dwBufferBytes;
            public DWORD dwReserved;
            [MarshalAs(UnmanagedType.LPStruct)]
            public WAVEFORMATEX lpwfxFormat;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        public class DSCBCAPS
        {
            public DWORD dwSize = (DWORD)Marshal.SizeOf(typeof(DSCBCAPS));
            public DWORD dwFlags;
            public DWORD dwBufferBytes;
            public DWORD dwReserved;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 4)]
        public struct DSBPOSITIONNOTIFY
        {
            public DWORD dwOffset;
            public HANDLE hEventNotify;
        }
        public enum KEYPROPERY_SUPPORT : ULONG
        {
            KSPROPERTY_SUPPORT_GET = 0x00000001,
            KSPROPERTY_SUPPORT_SET = 0x00000002,
        }

        [ComImport, Guid("279AFA85-4981-11CE-A521-0020AF0BE560"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IDirectSoundBuffer
        {
            [PreserveSig()]
            DSRESULT GetCaps([Out, MarshalAs(UnmanagedType.LPStruct)] out DSBCAPS lpDsbCaps);
            [PreserveSig()]
            DSRESULT GetCurrentPosition(out DWORD lpdwCurrentPlayCursor, out DWORD lpdwCurrentWriteCursor);
            [PreserveSig()]
            DSRESULT GetFormat(out WAVEFORMATEX lpwfxFormat, DWORD dwSizeAllocated, out DWORD lpdwSizeWritten);
            [PreserveSig()]
            DSRESULT GetVolume(out LONG lplVolume);
            [PreserveSig()]
            DSRESULT GetPan(out LONG lplPan);
            [PreserveSig()]
            DSRESULT GetFrequency(out DWORD lpdwFrequency);
            [PreserveSig()]
            DSRESULT GetStatus(out DSBSTATUS lpdwStatus);
            [PreserveSig()]
            DSRESULT Initialize(IDirectSound lpDirectSound, [In] DSBUFFERDESC lpcDSBufferDesc);
            [PreserveSig()]
            DSRESULT Lock(DWORD dwWriteCursor, DWORD dwWriteBytes, out IntPtr lplpvAudioPtr1, out DWORD lpdwAudioBytes1, out IntPtr lplpvAudioPtr2, out DWORD lpdwAudioBytes2, DSBLOCK_FLAGS dwFlags);
            [PreserveSig()]
            DSRESULT Play(DWORD dwReserved1, DWORD dwPriority, DSBPLAY_FLAGS dwFlags);
            [PreserveSig()]
            DSRESULT SetCurrentPosition(DWORD dwNewPosition);
            [PreserveSig()]
            DSRESULT SetFormat([In] WAVEFORMATEX lpcfxFormat);
            [PreserveSig()]
            DSRESULT SetVolume(LONG lVolume);
            [PreserveSig()]
            DSRESULT SetPan(LONG lPan);
            [PreserveSig()]
            DSRESULT SetFrequency(DWORD dwFrequency);
            [PreserveSig()]
            DSRESULT Stop();
            [PreserveSig()]
            DSRESULT Unlock(IntPtr lpvAudioPtr1, DWORD dwAudioBytes1, IntPtr lpvAudioPtr2, DWORD dwAudioBytes2);
            [PreserveSig()]
            DSRESULT Restore();
        };

        [ComImport, Guid("279AFA83-4981-11CE-A521-0020AF0BE560"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IDirectSound
        {
            [PreserveSig()]
            DSRESULT CreateSoundBuffer([In] DSBUFFERDESC lpcDSBufferDesc, out IDirectSoundBuffer lplpDirectSoundBuffer, [MarshalAs(UnmanagedType.IUnknown)] object pUnkOuter);
            [PreserveSig()]
            DSRESULT GetCaps(DSCAPS lpDSCaps);
            [PreserveSig()]
            DSRESULT DuplicateSoundBuffer(IDirectSoundBuffer lpDsbOriginal, out IDirectSoundBuffer lplpDsbDuplicate);
            [PreserveSig()]
            DSRESULT SetCooperativeLevel(HWND hwnd, DSSCL dwLevel);
            [PreserveSig()]
            DSRESULT Compact();
            [PreserveSig()]
            DSRESULT GetSpeakerConfig(out DWORD pdwSpeakerConfig);
            [PreserveSig()]
            DSRESULT SetSpeakerConfig(DWORD dwSpeakerConfig);
            [PreserveSig()]
            DSRESULT Initialize([In, MarshalAs(UnmanagedType.LPStruct)] Guid pcGuidDevice);
        }

        [ComImport, Guid("279AFA84-4981-11CE-A521-0020AF0BE560"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IDirectSound3DListener
        {
            [PreserveSig()]
            DSRESULT GetAllParameters(out DS3DLISTENER lpListener);
            [PreserveSig()]
            DSRESULT GetDistanceFactor(out D3DVALUE lpflDistanceFactor);
            [PreserveSig()]
            DSRESULT GetDopplerFactor(out D3DVALUE lpflDopplerFactor);
            [PreserveSig()]
            DSRESULT GetOrientation(out D3DVECTOR lpvOrientFront, out D3DVECTOR lpvOrientTop);
            [PreserveSig()]
            DSRESULT GetPosition(out D3DVECTOR lpvPosition);
            [PreserveSig()]
            DSRESULT GetRolloffFactor(out D3DVALUE lpflRolloffFactor);
            [PreserveSig()]
            DSRESULT GetVelocity(out D3DVECTOR lpvVelocity);
            [PreserveSig()]
            DSRESULT SetAllParameters([In] DS3DLISTENER lpcListener, DS3D dwApply);
            [PreserveSig()]
            DSRESULT SetDistanceFactor(D3DVALUE flDistanceFactor, DS3D dwApply);
            [PreserveSig()]
            DSRESULT SetDopplerFactor(D3DVALUE flDopplerFactor, DS3D dwApply);
            [PreserveSig()]
            DSRESULT SetOrientation(D3DVALUE xFront, D3DVALUE yFront, D3DVALUE zFront, D3DVALUE xTop, D3DVALUE yTop, D3DVALUE zTop, DS3D dwApply);
            [PreserveSig()]
            DSRESULT SetPosition(D3DVALUE x, D3DVALUE y, D3DVALUE z, DS3D dwApply);
            [PreserveSig()]
            DSRESULT SetRolloffFactor(D3DVALUE flRolloffFactor, DS3D dwApply);
            [PreserveSig()]
            DSRESULT SetVelocity(D3DVALUE x, D3DVALUE y, D3DVALUE z, DS3D dwApply);
            [PreserveSig()]
            DSRESULT CommitDeferredSettings();
        };

        [ComImport, Guid("279AFA86-4981-11CE-A521-0020AF0BE560"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IDirectSound3DBuffer
        {
            [PreserveSig()]
            DSRESULT GetAllParameters(out DS3DBUFFER lpDs3dBuffer);
            [PreserveSig()]
            DSRESULT GetConeAngles(out DWORD lpdwInsideConeAngle, out DWORD lpdwOutsideConeAngle);
            [PreserveSig()]
            DSRESULT GetConeOrientation(out D3DVECTOR lpvOrientation);
            [PreserveSig()]
            DSRESULT GetConeOutsideVolume(out LONG lplConeOutsideVolume);
            [PreserveSig()]
            DSRESULT GetMaxDistance(out D3DVALUE lpflMaxDistance);
            [PreserveSig()]
            DSRESULT GetMinDistance(out D3DVALUE lpflMinDistance);
            [PreserveSig()]
            DSRESULT GetMode(out DS3DMODE lpdwMode);
            [PreserveSig()]
            DSRESULT GetPosition(out D3DVECTOR lpvPosition);
            [PreserveSig()]
            DSRESULT GetVelocity(out D3DVECTOR lpvVelocity);
            [PreserveSig()]
            DSRESULT SetAllParameters([In] DS3DBUFFER lpcDs3dBuffer, DS3D dwApply);
            [PreserveSig()]
            DSRESULT SetConeAngles(DWORD dwInsideConeAngle, DWORD dwOutsideConeAngle, DS3D dwApply);
            [PreserveSig()]
            DSRESULT SetConeOrientation(D3DVALUE x, D3DVALUE y, D3DVALUE z, DS3D dwApply);
            [PreserveSig()]
            DSRESULT SetConeOutsideVolume(LONG lConeOutsideVolume, DS3D dwApply);
            [PreserveSig()]
            DSRESULT SetMaxDistance(D3DVALUE flMaxDistance, DS3D dwApply);
            [PreserveSig()]
            DSRESULT SetMinDistance(D3DVALUE flMinDistance, DS3D dwApply);
            [PreserveSig()]
            DSRESULT SetMode(DS3DMODE dwMode, DS3D dwApply);
            [PreserveSig()]
            DSRESULT SetPosition(D3DVALUE x, D3DVALUE y, D3DVALUE z, DS3D dwApply);
            [PreserveSig()]
            DSRESULT SetVelocity(D3DVALUE x, D3DVALUE y, D3DVALUE z, DS3D dwApply);
        };

        [ComImport, Guid("b0210781-89cd-11d0-af08-00a0c925cd16"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IDirectSoundCapture
        {
            [PreserveSig()]
            DSRESULT CreateCaptureBuffer([In] DSCBUFFERDESC lpDSCBufferDesc, out IDirectSoundCaptureBuffer lplpDirectSoundCaptureBuffer, [MarshalAs(UnmanagedType.IUnknown)] object pUnkOuter);
            [PreserveSig()]
            DSRESULT GetCaps(out DSCCAPS lpDSCCaps);
            [PreserveSig()]
            DSRESULT Initialize([In, MarshalAs(UnmanagedType.LPStruct)] Guid lpGuid);
        };

        [ComImport, Guid("b0210782-89cd-11d0-af08-00a0c925cd16"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IDirectSoundCaptureBuffer
        {
            [PreserveSig()]
            DSRESULT GetCaps(out DSCBCAPS lpDSCBCaps);
            [PreserveSig()]
            DSRESULT GetCurrentPosition(out DWORD lpdwCapturePosition, out DWORD lpdwReadPosition);
            [PreserveSig()]
            DSRESULT GetFormat(out WAVEFORMATEX lpwfxFormat, DWORD dwSizeAllocated, out DWORD lpdwSizeWritten);
            [PreserveSig()]
            DSRESULT GetStatus(out DSCBSTATUS lpdwStatus);
            [PreserveSig()]
            DSRESULT Initialize(IDirectSoundCapture lpDirectSoundCapture, [In] DSCBUFFERDESC lpcDSBufferDesc);
            [PreserveSig()]
            DSRESULT Lock(DWORD dwReadCursor, DWORD dwReadBytes, out IntPtr lplpvAudioPtr1, out DWORD lpdwAudioBytes1, out IntPtr lplpvAudioPtr2, out DWORD lpdwAudioBytes2, DSCBLOCK ENTIREBUFFER);
            [PreserveSig()]
            DSRESULT Start(DSCBSTART dwFlags);
            [PreserveSig()]
            DSRESULT Stop();
            [PreserveSig()]
            DSRESULT Unlock(IntPtr lpvAudioPtr1, DWORD dwAudioBytes1, IntPtr lpvAudioPtr2, DWORD dwAudioBytes2);
        };

        [ComImport, Guid("b0210783-89cd-11d0-af08-00a0c925cd16"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IDirectSoundNotify
        {
            [PreserveSig()]
            DSRESULT SetNotificationPositions(DWORD cPositionNotifies, [In] DSBPOSITIONNOTIFY[] lpcPositionNotifies);
        };
        [ComImport, Guid("31efac30-515c-11d0-a9aa-00aa0061be93"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
        public interface IKsPropertySet
        {
            [PreserveSig()]
            DSRESULT Get([In, MarshalAs(UnmanagedType.LPStruct)] Guid PropertySetId, ULONG PropertyId, IntPtr pPropertyParams, ULONG cbPropertyParams, IntPtr pPropertyData, ULONG cbPropertyData, out ULONG pcbReturnedData);
            [PreserveSig()]
            DSRESULT Set([In, MarshalAs(UnmanagedType.LPStruct)] Guid PropertySetId, ULONG PropertyId, IntPtr pPropertyParams, ULONG cbPropertyParams, IntPtr pPropertyData, ULONG cbPropertyData);
            [PreserveSig()]
            DSRESULT QuerySupport([In, MarshalAs(UnmanagedType.LPStruct)] Guid PropertySetId, ULONG PropertyId, out KEYPROPERY_SUPPORT pSupport);
        };

        static public class DirectSound
        {
            [DllImport("dsound.dll")]
            public static extern DSRESULT DirectSoundCreate([In, MarshalAs(UnmanagedType.LPStruct)] Guid lpcGuid, out IDirectSound ppDS, [MarshalAs(UnmanagedType.IUnknown)] object pUnkOuter);
            [DllImport("dsound.dll")]
            public static extern DSRESULT DirectSoundCreate(IntPtr lpcGuid, out IDirectSound ppDS, [MarshalAs(UnmanagedType.IUnknown)] object pUnkOuter);

            [DllImport("dsound.dll")]
            public static extern DSRESULT DirectSoundCaptureCreate([In, MarshalAs(UnmanagedType.LPStruct)] Guid lpGUID, out IDirectSoundCapture lplpDSC, [MarshalAs(UnmanagedType.IUnknown)] object pUnkOuter);
            [DllImport("dsound.dll")]
            public static extern DSRESULT DirectSoundCaptureCreate(IntPtr lpGUID, out IDirectSoundCapture lplpDSC, [MarshalAs(UnmanagedType.IUnknown)] object pUnkOuter);


            [DllImport("User32.Dll")]
            public static extern HWND GetDesktopWindow();
            [DllImport("Kernel32.Dll")]
            public static extern HANDLE CreateEvent(IntPtr lpEventAttributes, [In, MarshalAs(UnmanagedType.Bool)] bool bManualReset, [In, MarshalAs(UnmanagedType.Bool)] bool bInitialState, IntPtr lpName);
            [DllImport("Kernel32.Dll")]
            public static extern Int32 SetEvent(HANDLE hEvent);
            [DllImport("Kernel32.Dll")]
            public static extern Int32 CloseHandle(HANDLE hEvent);
            [DllImport("Kernel32.Dll")]
            public static extern DWORD WaitForSingleObject(HANDLE hHandle, DWORD dwMilliseconds);

            public const DWORD INFINITE = 0xffffffffU;
            public const DWORD WAIT_OBJECT_0 = 0x00000000U;
            public const DWORD WAIT_TIMEOUT = 0x00000102U;

            public const D3DVALUE DS3D_MINDISTANCEFACTOR = 0.0f;
            public const D3DVALUE DS3D_MAXDISTANCEFACTOR = 10.0f;
            public const D3DVALUE DS3D_DEFAULTDISTANCEFACTOR = 1.0f;

            public const D3DVALUE DS3D_MINROLLOFFFACTOR = 0.0f;
            public const D3DVALUE DS3D_MAXROLLOFFFACTOR = 10.0f;
            public const D3DVALUE DS3D_DEFAULTROLLOFFFACTOR = 1.0f;

            public const D3DVALUE DS3D_MINDOPPLERFACTOR = 0.0f;
            public const D3DVALUE DS3D_MAXDOPPLERFACTOR = 10.0f;
            public const D3DVALUE DS3D_DEFAULTDOPPLERFACTOR = 1.0f;

            public const D3DVALUE DS3D_DEFAULTMINDISTANCE = 1.0f;
            public const D3DVALUE DS3D_DEFAULTMAXDISTANCE = 1000000000.0f;

            public const D3DVALUE DS3D_MINCONEANGLE = 0;
            public const D3DVALUE DS3D_MAXCONEANGLE = 360;
            public const D3DVALUE DS3D_DEFAULTCONEANGLE = 360;

            public const D3DVALUE DS3D_DEFAULTCONEOUTSIDEVOLUME = 0;

            public const DWORD DSBFREQUENCY_MIN = 100;
            public const DWORD DSBFREQUENCY_MAX = 100000;
            public const DWORD DSBFREQUENCY_ORIGINAL = 0;

            public const LONG DSBPAN_LEFT = -10000;
            public const LONG DSBPAN_CENTER = 0;
            public const LONG DSBPAN_RIGHT = 10000;

            public const LONG DSBVOLUME_MIN = -10000;
            public const LONG DSBVOLUME_MAX = 0;

            public const DWORD DSBSIZE_MIN = 4;
            public const DWORD DSBSIZE_MAX = 0x0FFFFFFF;

            public const DWORD DSBPN_OFFSETSTOP = 0xFFFFFFFF;
        }
        public class CoTaskMemStructure<T> : IDisposable
        {
            private bool disposed = false;
            public CoTaskMemStructure(T obj)
            {
                Buffer = Marshal.AllocCoTaskMem(Marshal.SizeOf(obj));
                Marshal.StructureToPtr(obj, Buffer, false);
            }
            ~CoTaskMemStructure()
            {
                Dispose(false);
            }
            public void Dispose()
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }
            protected virtual void Dispose(bool disposing)
            {
                if (!this.disposed)
                {
                    Marshal.FreeCoTaskMem(this.Buffer);
                    this.disposed = true;
                }
            }
            public IntPtr Buffer
            {
                get;
                private set;
            }
        }
        public class MyDirectStream : IDisposable
        {
            public const int Frequency = 44100;
            private const int BufferLength = 4096;
            private const int NumChannels = 2;
            private const int BytesPerSample = 2;
            private IDirectSound directSound;
            private IDirectSoundBuffer directSoundBuffer;
            private System.Threading.AutoResetEvent arEvent;
            private System.Threading.Thread thread;
            private volatile bool exit = false;
            private bool disposed = false;
            ~MyDirectStream()
            {
                Dispose(false);
            }
            public void Dispose()
            {
                Dispose(true);
                GC.SuppressFinalize(this);
            }
            protected virtual void Dispose(bool disposing)
            {
                if (!this.disposed)
                {
                    this.Terminate(disposing);
                    this.disposed = true;
                }
            }
            private void Terminate(bool disposing)
            {
                if (thread != null)
                {
                    exit = true;
                    if (disposing)
                    {
                        arEvent.Set();
                        thread.Join();
                        arEvent.Close();
                    }
                    thread = null;
                    arEvent = null;
                    directSoundBuffer = null;
                    directSound = null;
                }
            }
            static void DsChk(DSRESULT hr)
            {
                if (hr < 0)
                {
                    throw new COMException("0x" + ((int)hr).ToString("X") + " " + hr.ToString(), (int)hr);
                }
            }
            public MyDirectStream()
            {
                DsChk(DirectSound.DirectSoundCreate(IntPtr.Zero, out directSound, null));
                {
                    DSCAPS dscaps = new DSCAPS();
                    DsChk(directSound.GetCaps(dscaps));
                    DsChk(directSound.SetCooperativeLevel(DirectSound.GetDesktopWindow(), DSSCL.DSSCL_PRIORITY));
                }

                {
                    DSBUFFERDESC dsbd = new DSBUFFERDESC();
                    dsbd.dwBufferBytes = BufferLength * NumChannels * BytesPerSample;
                    dsbd.dwFlags = DSBCAPS_FLAGS.DSBCAPS_GLOBALFOCUS | DSBCAPS_FLAGS.DSBCAPS_CTRLPOSITIONNOTIFY;
                    WAVEFORMATEX wfex = new WAVEFORMATEX();
                    wfex.wFormatTag = WAVE_FORMAT.WAVE_FORMAT_PCM;
                    wfex.nChannels = NumChannels;
                    wfex.nSamplesPerSec = Frequency;
                    wfex.nAvgBytesPerSec = Frequency * NumChannels * BytesPerSample;
                    wfex.nBlockAlign = NumChannels * BytesPerSample;
                    wfex.wBitsPerSample = BytesPerSample * 8;
                    wfex.cbSize = 0;
                    using (var str = new CoTaskMemStructure<WAVEFORMATEX>(wfex))
                    {
                        dsbd.lpwfxFormat = str.Buffer;
                        DsChk(directSound.CreateSoundBuffer(dsbd, out directSoundBuffer, null));
                    }
                }
            }

            public delegate void Output(float[] data, int numSamples);
            public void Raise()
            {
                arEvent.Set();
            }
            public void Play(Output Output)
            {
                exit = false;
                arEvent = new System.Threading.AutoResetEvent(false);
                thread = new System.Threading.Thread(() =>
                {
                    try
                    {
                        DWORD playCursor;
                        DWORD writeCursor;
                        DWORD writePos;
                        float[] work = new float[BufferLength * NumChannels];
                        Int16[] temp = new Int16[BufferLength * NumChannels];
                        writePos = 0;
                        while (!exit)
                        {
                            arEvent.WaitOne();
                            DsChk(directSoundBuffer.GetCurrentPosition(out playCursor, out writeCursor));
                            DWORD len = ((playCursor - writePos) % (BufferLength * NumChannels * BytesPerSample));
                            //System.Diagnostics.Debug.WriteLine("pc:" + playCursor + " wc:" + writeCursor + " wp:" + writePos + " len:" + len);
                            if (len == 0)
                            {
                                continue;
                            }
                            int num = (int)(len / BytesPerSample);
                            for (var i = 0; i < num; i++)
                            {
                                work[i] = 0.0f;
                            }
                            Output(work, num / NumChannels);
                            for (var i = 0; i < num; i++)
                            {
                                temp[i] = (Int16)(work[i] * 32767.0f);
                            }
                            IntPtr p1;
                            DWORD d1;
                            IntPtr p2;
                            DWORD d2;
                            DsChk(directSoundBuffer.Lock(writePos, len, out p1, out d1, out p2, out d2, 0));
                            Marshal.Copy(temp, 0, p1, (int)d1 / BytesPerSample);
                            if (d2 != 0)
                            {
                                Marshal.Copy(temp, (int)d1 / BytesPerSample, p2, (int)d2 / BytesPerSample);
                            }
                            DsChk(directSoundBuffer.Unlock(p1, d1, p2, d2));
                            writePos = (writePos + len) % (BufferLength * NumChannels * BytesPerSample);
                        }
                    }
#if !DEBUG
                    catch(Exception e)
                    {
                        throw e;
                    }
#endif
                    finally
                    {
                        directSoundBuffer.Stop();
                        exit = false;
                    }
                });
                thread.Priority = System.Threading.ThreadPriority.AboveNormal;
                thread.Start();
                DsChk(directSoundBuffer.Play(0, 0, DSBPLAY_FLAGS.DSBPLAY_LOOPING));
            }
            public void Stop()
            {
                Terminate(true);
            }
        }
    }
}
