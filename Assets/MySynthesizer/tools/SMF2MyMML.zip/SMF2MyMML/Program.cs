﻿using System;
using System.IO;
using System.Diagnostics;
using System.Text;

using MySpace;

namespace SMF2MyMML
{
    class Program
    {
        private static void WriteLine(string str)
        {
            Debug.WriteLine(str);
            Console.WriteLine(str);
        }
        private static void Write(string str)
        {
            Debug.Write(str);
            Console.Write(str);
        }
        enum ExitCode
        {
            Ok = 0,
            Usage = -1,
            ReadFailed = -2,
            PaserError = -3,
            WriteFailed = -4,
            IllegalData = -5,
        }
        static private bool Verbose = false;
        static private bool HitAnyKey = false;
        private static void Exit(ExitCode ec, string message)
        {
            WriteLine(message);
            if (HitAnyKey)
            {
                WriteLine("HIT ANY KEY!");
                Console.ReadKey();
            }
            Environment.Exit((int)ec);
        }
        static int Main(string[] args)
        {
            //Debug.Listeners.Add(new TextWriterTraceListener(Console.Out));
            bool error = false;
            string outputFile = null;
            string inputFile = null;
            bool expandDrum = false;
            uint port = 2;
            Encoding enc = null;
            var ct = StringComparison.CurrentCultureIgnoreCase;
            for (int i = 0; i < args.Length; i++)
            {
                var s = args[i];
                if (s[0] != '-')
                {
                    if (inputFile != null)
                    {
                        error = true;
                    }
                    inputFile = s;
                }
                else if (s.Equals("-v", ct) || s.Equals("-verbose", ct))
                {
                    Verbose = true;
                }
                else if (s.Equals("-h", ct) || s.Equals("-hit", ct))
                {
                    HitAnyKey = true;
                }
                else if (s.Equals("-ed", ct) || s.Equals("-expanddrum", ct))
                {
                    expandDrum = true;
                }
                else if (s.Equals("-p", ct) || s.Equals("-port", ct))
                {
                    if (((i + 1) < args.Length) && uint.TryParse(args[++i], out port))
                    {
                        if (port > 3)
                        {
                            error = true;
                        }
                    }
                    else
                    {
                        error = true;
                    }
                }
                else if (s.Equals("-o", ct) || s.Equals("-output", ct))
                {
                    if (outputFile != null)
                    {
                        error = true;
                    }
                    if ((i + 1) < args.Length)
                    {
                        if (!args[i + 1].StartsWith("-"))
                        {
                            outputFile = args[++i];
                        }
                    }
                }
                else if (s.Equals("-e", ct) || s.Equals("-encoding", ct))
                {
                    if (enc != null)
                    {
                        error = true;
                    }
                    int codePage;
                    if (((i + 1) < args.Length) && int.TryParse(args[++i], out codePage))
                    {
                        enc = System.Text.Encoding.GetEncoding(codePage);
                    }
                    else
                    {
                        error = true;
                    }
                }
                else
                {
                    error = true;
                }
            }
            if (error || (inputFile == null))
            {
                Exit(ExitCode.Usage, "usage:\n" +
                    "> SMF2MyMML input.mid [-v] [-h] [-e 65001] [-p 2] [-o [input.mml.txt]] [-ed]\n" +
                    "-v: Verbose\n" +
                    "-h: Hit Any Key!\n" +
                    "-e: Code page ex.932=sjis,65001=utf8\n" +
                    "-p: Port (0~3)\n" +
                    "-o: Output to file\n" +
                    "-ed: expand drum part (note -> program)"
                    );
            }
            if (outputFile == null)
            {
                int dot = inputFile.LastIndexOf('.');
                if (dot >= 0)
                {
                    outputFile = inputFile.Substring(0, inputFile.LastIndexOf('.'));
                }
                else
                {
                    outputFile = inputFile;
                }
                outputFile += ".mml.txt";
            }
            if (enc == null)
            {
                enc = System.Text.Encoding.UTF8;
            }
#if !DEBUG
            try
#endif
            {
                MySMFSequence smfSequence;
                using (var smf = new FileStream(inputFile, FileMode.Open, FileAccess.Read))
                {
                    smfSequence = MySMFSequence.Parse(smf);
                }
                MySpace.MySMF2MML smf2mml = new MySpace.MySMF2MML();
                smf2mml.Verbose = Verbose;
                smf2mml.Output += WriteLine;
                smf2mml.ExpandDrum = expandDrum;
                smf2mml.Encoding = enc;
                var txt = smf2mml.Convert(smfSequence, port);
                using (StreamWriter mml = new StreamWriter(outputFile, false, Encoding.UTF8))
                {
                    mml.Write(txt);
                }
            }
#if !DEBUG
            catch (System.Exception e)
            {
                Exit(ExitCode.WriteFailed, e.Message);
            }
#endif
            Exit(ExitCode.Ok, "Ok..");
            return 0;
        }
    }
}
